# Manual para Comprender el TDAH en Niños
### Licda. Sandra De Jesús

Página web del combo educativo — Manual TDAH + Terapia y Arte para Niños.

**Enlace de compra:** https://go.hotmart.com/U106094529P  
**WhatsApp:** 809-834-0282

---
Sitio desplegado con GitHub Pages.
